@extends('layouts.shop')

@section('title', $product->name)

@push('styles')
    <style>
        /* ======= Scoped styles for product show (dark, Corsair-like) ======= */
        :root{
            --bg0:#0a0d12;
            --bg1:#0e131a;
            --card:#10161f;
            --text:#eef2f6;
            --muted:#c2cad6;
            --border:rgba(255,255,255,.06);
            --accent:#ffd60a;
            --accent-2:#fff1a6;
        }
        #product-show { color:var(--text); }
        #product-show .text-muted{ color:var(--muted)!important; }

        /* Cards */
        #product-show .card.bg-dark{
            background:linear-gradient(180deg,var(--card),var(--bg0));
            border:1px solid var(--border)!important;
            border-radius:16px;
            box-shadow: 0 10px 30px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.03);
        }

        /* Gallery */
        #product-show .gallery-card{ background:transparent!important; border:0!important; box-shadow:none!important; }
        #product-show .gallery-frame{
            aspect-ratio: 16/10;
            background:#000;
            border:1px solid rgba(255,255,255,.08);
            border-radius:16px;
            display:flex; align-items:center; justify-content:center;
            overflow:hidden;
        }
        #product-show #mainImage{ width:100%; height:100%; object-fit:contain; }

        #product-show .thumb img{
            width:84px;height:84px;object-fit:cover;
            background:#000;border-radius:12px;
            border:1px solid rgba(255,255,255,.10);
            transition:transform .15s ease,border-color .15s ease, box-shadow .15s ease;
        }
        #product-show .thumb:hover img{ transform:translateY(-2px); border-color:var(--accent); box-shadow:0 8px 20px rgba(255,214,10,.15);}
        #product-show .thumb.is-active img{ outline:2px solid var(--accent); }

        /* Section titles */
        #product-show .section-title{
            color:var(--text)!important; letter-spacing:.3px;
            font-weight:800; text-transform:uppercase;
            margin-bottom:.5rem;
        }
        #product-show .section-title::after{
            content:""; display:block; width:42px; height:3px;
            background:linear-gradient(90deg,var(--accent),rgba(255,214,10,.15));
            border-radius:3px; margin-top:.35rem;
        }

        /* Feature strip */
        #product-show .feature-strip .box{
            background:linear-gradient(180deg,#0b1016,#0a0f14);
            border:1px solid var(--border);
            border-radius:14px; padding:18px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
        }
        #product-show .feature-strip .box .label{ color:var(--muted); font-size:.8rem; }
        #product-show .feature-strip .box .value{ color:var(--text); font-weight:700; }

        /* Price box */
        #product-show .price-box{
            background:linear-gradient(180deg,#07090c,#000);
            border:1px solid var(--border);
            border-radius:14px; padding:14px 18px;
            box-shadow: 0 10px 30px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.04);
            overflow:hidden;
        }
        #product-show .price{ color:var(--accent); font-weight:800; text-shadow:0 4px 16px rgba(255,214,10,.25); }
        #product-show .old{ color:rgba(255,255,255,.55); text-decoration:line-through; }
        #product-show .badge-discount{
            background: rgba(255,214,10,.15);
            color: var(--accent);
            border: 1px solid var(--accent);
        }

        /* Buttons */
        #product-show .btn-primary{
            background:var(--accent); border-color:#e5c601; color:#111; font-weight:700;
            box-shadow:0 10px 22px rgba(255,214,10,.22);
        }
        #product-show .btn-primary:hover{ filter:brightness(.96); transform:translateY(-1px); }
        #product-show .btn-light{ background:#f6f7f8; color:#111; border-color:#e6e7ea; }
        #product-show .btn-light:hover{ background:#fff; }

        /* Policy items */
        #product-show .policy-item{
            background:var(--card);
            border:1px solid var(--border);
            border-radius:12px; padding:10px 12px;
            color:var(--text);
        }
        #product-show .policy-item i{ color:var(--accent); }

        /* Specs tiles */
        #product-show .spec-tile{
            background:#000;
            border:1px solid var(--border);
            border-radius:12px; padding:14px;
        }
        #product-show .spec-tile .label{ color:var(--muted); }
        #product-show .spec-tile .value{ color:var(--text); font-weight:600; }

        /* Áp dụng font có hỗ trợ tiếng Việt */
        html, body, #product-show {
            font-family: 'Be Vietnam Pro', system-ui, -apple-system, 'Segoe UI', Roboto,
            'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            text-rendering: optimizeLegibility;
        }

        /* Tiêu đề/heading & giá – dùng Saira Condensed */
        #product-show .section-title,
        #product-show h1, #product-show h2, #product-show h3,
        #product-show .price {
            font-family: 'Saira Condensed', 'Be Vietnam Pro', sans-serif;
            letter-spacing: .25px;
        }

        /* Tuỳ chọn: làm số nhìn đều */
        #product-show .price,
        #product-show .spec-tile .value {
            font-variant-numeric: tabular-nums;
            font-feature-settings: "tnum" 1;
        }


    </style>
@endpush

@section('content')
    @php
        use Illuminate\Support\Facades\Storage;
        use Illuminate\Support\Facades\Route;

        // Build gallery: prefer product_images; fallback scan folder
        $gallery = $product->images
            ->pluck('url')
            ->filter()
            ->filter(fn($rel) => Storage::disk('public')->exists(ltrim($rel, '/')))
            ->map(fn($rel) => Storage::disk('public')->url(ltrim($rel, '/')))
            ->values();
        if ($gallery->isEmpty()) {
          $dir = "products/{$product->id}";
          $files = collect(Storage::disk('public')->files($dir))
            ->filter(fn($p) => preg_match('/\.(jpe?g|png|webp)$/i', $p))
            ->sort()->values();
          $gallery = $files->map(fn($p) => Storage::disk('public')->url($p));
        }

        // Price
        $price = (int)($product->price ?? 0);
        $old   = (int)($product->old_price ?? 0);
        if (!$old && ($product->discount_percent ?? 0) > 0) {
            $old = (int) round($price / (1 - $product->discount_percent/100));
        }

        // Attributes JSON fallback for specs
        $attrRaw = $product->attributes;
  $attr = is_array($attrRaw) ? $attrRaw : (json_decode($attrRaw ?? '', true) ?: []);

  $get = function(array $keys, $default = '—') use ($attr) {
      foreach ($keys as $k) {
          foreach ([$k, strtolower($k), strtoupper($k)] as $kk) {
              if (isset($attr[$kk]) && $attr[$kk] !== '') return $attr[$kk];
          }
      }
      return $default;
  };

  $cpu     = $product->cpu     ?? $get(['CPU','Chip','Vi xử lý']);
  $ram     = $product->ram     ?? ($product->ram_gb ? $product->ram_gb.' GB' : $get(['RAM','Bộ nhớ']));
  $storage = $product->storage ?? $get(['Storage','Lưu trữ','Ổ cứng','SSD','HDD']);
  $gpu     = $product->gpu     ?? $get(['GPU','Card đồ hoạ','Card']);
  $display = $product->display ?? $get(['Display','Màn hình','Screen']);
  $weight  = $product->weight  ?? $get(['Weight','Trọng lượng']);

  // ---- Fallback URL thanh toán (giữ nguyên nếu bạn đã có)
  $checkoutUrl = Route::has('cart.checkout')
      ? route('cart.checkout')
      : (Route::has('cart.index') ? route('cart.index') : url('/cart'));
    @endphp

    <div id="product-show" class="container py-4">

        {{-- Breadcrumb --}}
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb bg-transparent p-0 m-0">
                <li class="breadcrumb-item"><a class="text-decoration-none" href="{{ route('products.index') }}">Sản phẩm</a></li>
                @if($product->brand?->name)
                    <li class="breadcrumb-item"><span class="text-muted">Laptop {{ $product->brand->name }}</span></li>
                @endif
                <li class="breadcrumb-item active" aria-current="page">{{ $product->name }}</li>
            </ol>
        </nav>

        <div class="row g-4 align-items-start">
            {{-- LEFT: Gallery --}}
            <div class="col-lg-6">

                <div class="card bg-dark shadow-sm gallery-card">
                    <div class="card-body">
                        <div class="gallery-frame">
                            <img id="mainImage" class="img-fluid" src="{{ $product->cover_image }}" alt="{{ $product->name }}">
                        </div>
                    </div>
                </div>

                {{-- Thumbnails --}}
                @if($gallery->isNotEmpty())
                    <div class="d-flex flex-wrap gap-2 mt-3">
                        @foreach($gallery as $i => $src)
                            <button type="button"
                                    class="thumb btn p-0 border-0 bg-transparent {{ $i===0 ? 'is-active' : '' }}"
                                    data-src="{{ $src }}"
                                    title="Ảnh {{ $i+1 }}">
                                <img class="rounded" src="{{ $src }}" alt="thumb {{ $i+1 }}">
                            </button>
                        @endforeach
                    </div>
                @endif

                {{-- Feature strip --}}
                <div class="mt-4 feature-strip">
                    <h6 class="section-title mb-2">Thông số nổi bật</h6>
                    <div class="row g-2">
                        <div class="col-6 col-md-3"><div class="box h-100">
                                <div class="label">CPU</div><div class="value">{{ $cpu }}</div>
                            </div></div>
                        <div class="col-6 col-md-3"><div class="box h-100">
                                <div class="label">RAM</div><div class="value">{{ $ram }}</div>
                            </div></div>
                        <div class="col-6 col-md-3"><div class="box h-100">
                                <div class="label">Lưu trữ</div><div class="value">{{ $storage }}</div>
                            </div></div>
                        <div class="col-6 col-md-3"><div class="box h-100">
                                <div class="label">Đồ hoạ</div><div class="value">{{ $gpu }}</div>
                            </div></div>
                    </div>
                    <a href="#specs" class="btn btn-outline-secondary btn-sm mt-3">Xem tất cả thông số</a>
                </div>
            </div>

            {{-- RIGHT: Title + Price + CTAs + Policies --}}
            <div class="col-lg-6">
                <div class="card bg-dark shadow-sm">
                    <div class="card-body">
                        <h1 class="h4 mb-2">{{ $product->name }}</h1>

                        <div class="price-box mb-3">
                            <div class="d-flex flex-wrap align-items-baseline gap-3">
                                <div class="display-6 price">{{ number_format($price, 0, ',', '.') }}₫</div>
                                @if($old && $old > $price)
                                    <div class="old">{{ number_format($old, 0, ',', '.') }}₫</div>
                                @endif
                                @if(($product->discount_percent ?? 0) > 0)
                                    <span class="badge badge-discount">{{ '-'.$product->discount_percent.'%' }}</span>
                                @endif
                            </div>
                        </div>

                        <div class="d-flex gap-2 mb-3">
                            <form method="POST" action="{{ route('cart.add') }}">
                                @csrf
                                <input type="hidden" name="product_id" value="{{ $product->id }}">
                                <button class="btn btn-primary">
                                    <i class="bi bi-cart-plus me-1"></i> Thêm vào giỏ
                                </button>
                            </form>
                            <a href="{{ $checkoutUrl }}" class="btn btn-light">Mua ngay</a>
                        </div>

                        <div class="mt-3">
                            <h6 class="section-title mb-2">Chính sách sản phẩm</h6>
                            <ul class="list-unstyled row g-2">
                                <li class="col-12 col-md-6">
                                    <div class="policy-item d-flex align-items-center gap-2">
                                        <i class="bi bi-shield-check"></i>
                                        <span>Hàng chính hãng – Bảo hành {{ $product->warranty_months ? $product->warranty_months.' tháng' : '24 tháng' }}</span>
                                    </div>
                                </li>
                                <li class="col-12 col-md-6">
                                    <div class="policy-item d-flex align-items-center gap-2">
                                        <i class="bi bi-truck"></i>
                                        <span>Giao hàng miễn phí toàn quốc</span>
                                    </div>
                                </li>
                                <li class="col-12 col-md-6">
                                    <div class="policy-item d-flex align-items-center gap-2">
                                        <i class="bi bi-headset"></i>
                                        <span>Hỗ trợ cài đặt miễn phí</span>
                                    </div>
                                </li>
                                <li class="col-12 col-md-6">
                                    <div class="policy-item d-flex align-items-center gap-2">
                                        <i class="bi bi-people"></i>
                                        <span>Chiết khấu doanh nghiệp</span>
                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        {{-- Description --}}
        <div class="card bg-dark shadow-sm mt-4" id="desc">
            <div class="card-body">
                <h2 class="section-title">Mô tả sản phẩm</h2>
                <div class="collapse show" id="descCollapse">
                    <div class="text-light">
                        {!! nl2br(e($product->description ?? 'Đang cập nhật nội dung…')) !!}
                    </div>
                </div>
                <button class="btn btn-outline-secondary btn-sm mt-3" data-bs-toggle="collapse" data-bs-target="#descCollapse">
                    Đọc thêm / Thu gọn
                </button>
            </div>
        </div>

        {{-- Full specs --}}
        <div class="card bg-dark shadow-sm mt-4" id="specs">
            <div class="card-body">
                <h2 class="section-title">Thông số kỹ thuật</h2>
                <div class="row row-cols-1 row-cols-md-2 g-3">
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">CPU</span><span class="value">{{ $cpu }}</span></div></div>
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">RAM</span><span class="value">{{ $ram }}</span></div></div>
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">Lưu trữ</span><span class="value">{{ $storage }}</span></div></div>
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">Card đồ hoạ</span><span class="value">{{ $gpu }}</span></div></div>
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">Màn hình</span><span class="value">{{ $display }}</span></div></div>
                    <div class="col"><div class="spec-tile d-flex justify-content-between">
                            <span class="label">Trọng lượng</span><span class="value">{{ $weight }}</span></div></div>
                </div>
            </div>
        </div>

        {{-- Reviews stub --}}
        <div class="card bg-dark shadow-sm mt-4">
            <div class="card-body">
                <h2 class="section-title">Đánh giá và bình luận</h2>
                <p class="text-muted mb-2">Tính năng bình luận đang được cập nhật.</p>
                <form>
                    <textarea class="form-control bg-black text-light border-secondary" rows="3" placeholder="Nhập nội dung bình luận..." disabled></textarea>
                    <button class="btn btn-secondary mt-2" disabled>Gửi bình luận</button>
                </form>
            </div>
        </div>

    </div>

    @push('scripts')
        <script>
            // Thumbnail click -> change main image & active state
            document.querySelectorAll('#product-show .thumb[data-src]').forEach(btn => {
                btn.addEventListener('click', () => {
                    const src = btn.getAttribute('data-src');
                    const main = document.getElementById('mainImage');
                    if (src && main) main.src = src;
                    document.querySelectorAll('#product-show .thumb').forEach(b=>b.classList.remove('is-active'));
                    btn.classList.add('is-active');
                });
            });
        </script>
    @endpush
@endsection
