import './bootstrap';
import 'bootstrap';         // chỉ JS
import Alpine from 'alpinejs';
window.Alpine = Alpine;
Alpine.start();

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.dropdown-mega').forEach(menu => {
        const items  = menu.querySelectorAll('.mega-item');
        const right  = menu.querySelector('.mega-right');
        const panels = menu.querySelectorAll('.mega-panel');

        const showPanel = (target) => {
            if (!right) return;
            panels.forEach(p => p.classList.toggle('show', '#'+p.id === target || p.id === (target || '').replace('#','')));
            right.classList.add('visible');
        };
        const hidePanel = () => {
            if (!right) return;
            right.classList.remove('visible');
            panels.forEach(p => p.classList.remove('show'));
            items.forEach(x => x.classList.remove('active'));
        };

        items.forEach(it => {
            const target = it.getAttribute('data-target');
            if (!target) return;
            it.addEventListener('mouseenter', () => { items.forEach(x => x.classList.remove('active')); it.classList.add('active'); showPanel(target); });
            it.addEventListener('click', e => { e.preventDefault(); items.forEach(x => x.classList.remove('active')); it.classList.add('active'); showPanel(target); });
        });

        menu.addEventListener('mouseleave', hidePanel);
        const parent = menu.closest('.dropdown');
        if (parent){
            parent.addEventListener('hidden.bs.dropdown', hidePanel);
            parent.addEventListener('shown.bs.dropdown', hidePanel); // mở lên là sạch
        }
    });
});
